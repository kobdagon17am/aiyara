
 <style>
    .bg-footer {
    color: white;
    font-size: 13px;
    margin: 0 auto;
    background: black;
    padding: 10px 0 10px;
} 
     
     .textcenter {
         text-align: center;
    margin: 0 auto;
     }
</style>
 
 
 <div class="container-fluid bg-footer">
    <div class="container" style="text-align: center;">
    <div class="row">
    <div class="textcenter" >700/66 Moo 6, Bangna-Trad Rd. Km57, Tambol Nongmaidaeng, A.Muang, Chonburi 20000</div>
</div>
</div>
</div>